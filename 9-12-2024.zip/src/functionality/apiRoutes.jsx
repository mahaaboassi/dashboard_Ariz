
export const Host = "https://dashboard-ariz-2.onrender.com/api/"

export const apiRouter = {
    auth : {

    },
    pdf : {
        sendEmail : ""
    }
}