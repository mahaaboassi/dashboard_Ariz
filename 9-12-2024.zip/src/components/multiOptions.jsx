function MultiOptions({withTitle,options}) {
    return (<div>
        
    </div>  );
}

export default MultiOptions;